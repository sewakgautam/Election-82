// pages/api/results.js
// Server-side API route — runs on Vercel edge, scrapes ECN on every call
// Vercel will cache & revalidate this every 60 seconds via ISR

import { fetchElectionData } from '../../lib/scraper';

export default async function handler(req, res) {
  try {
    const data = await fetchElectionData();
    
    // Allow CORS for self-requests
    res.setHeader('Access-Control-Allow-Origin', '*');
    // Cache for 60s on CDN, stale-while-revalidate for 30s more
    res.setHeader('Cache-Control', 's-maxage=60, stale-while-revalidate=30');
    res.setHeader('Content-Type', 'application/json');
    
    res.status(200).json(data);
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({
      error: 'Failed to fetch election data',
      message: err.message,
    });
  }
}
