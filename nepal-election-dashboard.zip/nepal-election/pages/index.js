import { useState, useEffect, useCallback } from 'react';
import Head from 'next/head';

const REFRESH_INTERVAL = 60000; // 60 seconds

export default function Home() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastFetch, setLastFetch] = useState(null);
  const [countdown, setCountdown] = useState(60);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/results');
      if (!res.ok) throw new Error('Failed to fetch');
      const json = await res.json();
      setData(json);
      setError(null);
      setLastFetch(new Date());
      setCountdown(60);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, REFRESH_INTERVAL);
    return () => clearInterval(interval);
  }, [fetchData]);

  // Countdown timer
  useEffect(() => {
    if (!lastFetch) return;
    const t = setInterval(() => {
      const elapsed = Math.floor((Date.now() - lastFetch.getTime()) / 1000);
      setCountdown(Math.max(0, 60 - elapsed));
    }, 1000);
    return () => clearInterval(t);
  }, [lastFetch]);

  const parties = data?.parties || [];
  const meta = data?.meta || {};
  const top3 = parties.slice(0, 3);
  const maxSeats = parties[0]?.total || 1;
  const totalWon = parties.reduce((s, p) => s + p.total, 0);
  const majority = meta.majority || 138;

  return (
    <>
      <Head>
        <title>Nepal Election 2082 — Live Results</title>
        <meta name="description" content="Live Nepal election results 2082 — party-wise seat tally from the Election Commission of Nepal" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main className="content" style={{ maxWidth: 1100, margin: '0 auto', padding: '40px 20px 80px' }}>

        {/* Header */}
        <header style={{ marginBottom: 48, display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: 24 }}>
          <div>
            <h1 className="font-serif" style={{ fontSize: 'clamp(28px,5vw,48px)', fontWeight: 400, lineHeight: 1.1, color: 'var(--text)', letterSpacing: -0.5 }}>
              Nepal <em style={{ fontStyle: 'italic', color: 'var(--accent)' }}>Election</em><br />Results 2082
            </h1>
            <p style={{ marginTop: 8, fontSize: 11, letterSpacing: '2px', textTransform: 'uppercase', color: 'var(--muted)' }}>
              House of Representatives · Federal Parliament · 2026
            </p>
          </div>

          <div style={{ textAlign: 'right' }}>
            <div style={{ display: 'inline-block', background: meta.live ? '#16a34a' : 'var(--border)', color: meta.live ? '#fff' : 'var(--muted)', fontSize: 10, fontWeight: 500, letterSpacing: '1.5px', textTransform: 'uppercase', padding: '5px 12px', borderRadius: 2, marginBottom: 8 }}>
              {meta.live ? '● Live' : '○ Counting Pending'}
            </div>
            <div className="font-serif" style={{ fontSize: 52, lineHeight: 1, color: 'var(--text)' }}>{meta.totalSeats || 275}</div>
            <div style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: 2, textTransform: 'uppercase' }}>Total Seats</div>
            <div style={{ fontSize: 10, color: 'var(--majority)', letterSpacing: 1, marginTop: 4, textTransform: 'uppercase' }}>▸ Majority: {majority} seats</div>
          </div>
        </header>

        {/* Status bar */}
        <div style={{ marginBottom: 28, padding: '12px 18px', background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
          <div style={{ fontSize: 11, color: 'var(--muted)' }}>
            <span>Source: </span>
            <a href="https://result.election.gov.np" target="_blank" rel="noopener noreferrer" style={{ color: 'var(--accent)', textDecoration: 'none' }}>
              result.election.gov.np
            </a>
            {meta.lastUpdated && (
              <span> · ECN updated: {new Date(meta.lastUpdated).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
            )}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            {loading && (
              <div style={{ width: 14, height: 14, border: '2px solid var(--border)', borderTopColor: 'var(--accent)', borderRadius: '50%' }} className="spinner" />
            )}
            <span style={{ fontSize: 11, color: 'var(--muted)' }}>
              Refreshes in <span style={{ color: 'var(--accent)' }}>{countdown}s</span>
            </span>
            <button
              onClick={fetchData}
              disabled={loading}
              style={{ fontSize: 10, letterSpacing: '1px', textTransform: 'uppercase', background: 'var(--border)', color: loading ? 'var(--muted)' : 'var(--text)', border: 'none', padding: '6px 12px', borderRadius: 3, cursor: loading ? 'not-allowed' : 'pointer', fontFamily: 'inherit' }}
            >
              ↺ Refresh
            </button>
          </div>
        </div>

        {/* Error notice */}
        {meta.error && (
          <div style={{ marginBottom: 24, padding: '14px 18px', background: '#ff6b3511', border: '1px solid #ff6b3544', borderRadius: 6, fontSize: 12, color: '#ff9e6b' }}>
            ⚠ {meta.error}
          </div>
        )}

        {/* Parliament bar */}
        <div style={{ marginBottom: 32, background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 8, padding: '24px 24px 20px' }}>
          <div style={{ fontSize: 10, letterSpacing: '2px', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 18 }}>
            Seat Distribution — All Parties
            <span style={{ marginLeft: 16, color: 'var(--text)' }}>{totalWon} / {meta.totalSeats || 275} seats declared</span>
          </div>

          {/* Progress bar */}
          <div style={{ position: 'relative', marginBottom: 10 }}>
            {/* Majority marker */}
            <div style={{
              position: 'absolute',
              left: `${(majority / (meta.totalSeats || 275)) * 100}%`,
              top: -20,
              transform: 'translateX(-50%)',
              fontSize: 9,
              color: 'var(--majority)',
              letterSpacing: '1px',
              textTransform: 'uppercase',
              whiteSpace: 'nowrap'
            }}>
              ↓ {majority}
            </div>

            <div style={{ display: 'flex', height: 52, borderRadius: 4, overflow: 'hidden', gap: 1, background: 'var(--border)' }}>
              {totalWon > 0 ? parties.filter(p => p.total > 0).map((p, i) => (
                <div
                  key={p.name}
                  title={`${p.name}: ${p.total} seats`}
                  style={{
                    flex: p.total,
                    background: p.color,
                    transition: 'flex 0.8s ease',
                    cursor: 'help',
                  }}
                />
              )) : (
                <div style={{ flex: 1, background: 'var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, color: 'var(--muted)' }}>
                  Counting in progress…
                </div>
              )}
            </div>

            {/* Majority line */}
            <div style={{
              position: 'absolute',
              top: 0,
              bottom: 0,
              left: `${(majority / (meta.totalSeats || 275)) * 100}%`,
              width: 2,
              background: 'var(--majority)',
              zIndex: 5,
            }} />
          </div>

          {/* Legend */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14, marginTop: 16 }}>
            {parties.slice(0, 9).map(p => (
              <div key={p.name} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: 'var(--muted)' }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: p.color, flexShrink: 0 }} />
                {p.abbr}
              </div>
            ))}
          </div>
        </div>

        {/* Top 3 cards */}
        {top3.length > 0 && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(160px,1fr))', gap: 12, marginBottom: 32 }}>
            {top3.map((p, i) => (
              <div key={p.name} style={{ background: 'var(--card)', border: `1px solid ${i === 0 ? p.color + '55' : 'var(--border)'}`, borderRadius: 6, padding: 20 }}>
                <div className="font-serif" style={{ fontSize: 36, lineHeight: 1, marginBottom: 6, color: p.color }}>{p.total}</div>
                <div style={{ fontSize: 12, color: 'var(--text)', marginBottom: 2 }}>{p.abbr}</div>
                <div style={{ fontSize: 10, color: 'var(--muted)' }}>{p.name.slice(0, 28)}</div>
                <div style={{ marginTop: 10, fontSize: 10, color: 'var(--muted)' }}>
                  FPTP <span style={{ color: 'var(--text)' }}>{p.fptp}</span>
                  <span style={{ margin: '0 6px' }}>·</span>
                  PR <span style={{ color: 'var(--text)' }}>{p.pr}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Full party table */}
        <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 8, overflow: 'hidden' }}>
          <div style={{ padding: '18px 24px 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
            <div style={{ fontSize: 10, letterSpacing: '2px', textTransform: 'uppercase', color: 'var(--muted)' }}>All Parties · Seat Breakdown</div>
            <div style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: '1px' }}>FPTP (165) + PR (110) = 275 Total</div>
          </div>

          {/* Table header */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '32px 1fr 70px 70px 80px 110px',
            padding: '12px 24px',
            marginTop: 14,
            borderBottom: '1px solid var(--border)',
            fontSize: 10,
            letterSpacing: '1.5px',
            textTransform: 'uppercase',
            color: 'var(--muted)',
          }}>
            <div>#</div>
            <div>Party</div>
            <div style={{ textAlign: 'right' }}>FPTP</div>
            <div style={{ textAlign: 'right' }}>PR</div>
            <div style={{ textAlign: 'right' }}>Total</div>
            <div>Share</div>
          </div>

          {/* Rows */}
          {loading && parties.length === 0 ? (
            <div style={{ padding: '40px 24px', textAlign: 'center', color: 'var(--muted)', fontSize: 13 }}>
              <div style={{ width: 20, height: 20, border: '2px solid var(--border)', borderTopColor: 'var(--accent)', borderRadius: '50%', margin: '0 auto 12px', animationName: 'spin', animationDuration: '0.8s', animationTimingFunction: 'linear', animationIterationCount: 'infinite' }} className="spinner" />
              Fetching live data from Election Commission of Nepal…
            </div>
          ) : parties.length === 0 ? (
            <div style={{ padding: '40px 24px', textAlign: 'center', color: 'var(--muted)', fontSize: 13 }}>
              No results declared yet. Counting begins after polls close.
            </div>
          ) : (
            parties.map((p, i) => {
              const pct = totalWon > 0 ? ((p.total / (meta.totalSeats || 275)) * 100).toFixed(1) : '0.0';
              const barW = maxSeats > 0 ? Math.round((p.total / maxSeats) * 80) : 0;
              const rankColor = i === 0 ? 'var(--accent)' : i === 1 ? '#dc2626' : i === 2 ? '#60a5fa' : 'var(--muted)';
              return (
                <div
                  key={p.name}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '32px 1fr 70px 70px 80px 110px',
                    padding: '13px 24px',
                    borderBottom: '1px solid rgba(255,255,255,0.04)',
                    alignItems: 'center',
                    background: i < 3 && p.total > 0 ? `${p.color}08` : 'transparent',
                    transition: 'background 0.15s',
                  }}
                >
                  <div style={{ fontSize: 10, color: rankColor, fontWeight: 500 }}>{i + 1}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 10, height: 10, borderRadius: '50%', background: p.color, flexShrink: 0 }} />
                    <div>
                      <div style={{ fontSize: 13, color: 'var(--text)' }}>{p.name}</div>
                      <div style={{ fontSize: 10, color: 'var(--muted)', marginTop: 1 }}>{p.abbr}</div>
                    </div>
                  </div>
                  <div style={{ textAlign: 'right', fontSize: 16, color: 'var(--muted)', fontFamily: 'Instrument Serif, serif' }}>{p.fptp}</div>
                  <div style={{ textAlign: 'right', fontSize: 16, color: 'var(--muted)', fontFamily: 'Instrument Serif, serif' }}>{p.pr}</div>
                  <div style={{ textAlign: 'right', fontSize: 22, color: 'var(--accent)', fontFamily: 'Instrument Serif, serif' }}>{p.total}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{ height: 6, width: Math.max(barW, p.total > 0 ? 4 : 0), background: p.color, borderRadius: 3, transition: 'width 0.8s ease' }} />
                    <span style={{ fontSize: 10, color: 'var(--muted)' }}>{pct}%</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div style={{ marginTop: 32, fontSize: 10, color: 'var(--muted)', letterSpacing: '0.5px', lineHeight: 1.8, borderTop: '1px solid var(--border)', paddingTop: 20 }}>
          <p>Data scraped live from the <a href="https://result.election.gov.np" target="_blank" rel="noopener noreferrer" style={{ color: 'var(--accent)', textDecoration: 'none' }}>Election Commission of Nepal</a> · FPTP = First Past The Post (165 seats) · PR = Proportional Representation (110 seats)</p>
          <p style={{ marginTop: 4 }}>Total HoR seats = 275 · Majority threshold = 138 seats · Election date: Falgun 21, 2082 BS (March 5, 2026)</p>
          <p style={{ marginTop: 4 }}>Dashboard refreshes every 60 seconds automatically. All data is official and sourced directly from ECN.</p>
        </div>

      </main>
    </>
  );
}
